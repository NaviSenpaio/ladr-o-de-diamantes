var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var player = createSprite(20,380, 15, 15);
player.shapeColor = "red";

var diamante = createSprite(380, 20, 15, 15);
diamante.shapeColor = "rgb(15, 100,200)";

var botao = createSprite(160, 380, 15,15);
botao.shapeColor = "yellow";

var laser1 = createSprite(330,20, 5, 90); 
laser1.shapeColor = "green";

var laser2 = createSprite(180,330, 90, 5);
laser2.shapeColor = "green"; 

var guarda1 = createSprite(25, 120, 15, 15);
guarda1.shapeColor = "blue";

var guarda2 = createSprite(390, 220, 15, 15);
guarda2.shapeColor = "blue";

var gameState = "serve";

var papelao1 = createSprite(0,340, 150, 10); 
papelao1.shapeColor = "maroon";

var papelao2 = createSprite(40,240, 10, 90); 
papelao2.shapeColor = "maroon";

var papelao3 = createSprite(130,390, 10, 500); 
papelao3.shapeColor = "maroon";

var papelao4 = createSprite(80,240, 90, 10); 
papelao4.shapeColor = "maroon";

var papelao5 = createSprite(30,100, 90, 10); 
papelao5.shapeColor = "maroon";

var papelao6 = createSprite(180,350, 100, 10); 
papelao6.shapeColor = "maroon";

var papelao7 = createSprite(280,370, 10, 80); 
papelao7.shapeColor = "maroon";

var papelao8 = createSprite(350,340, 10, 140); 
papelao8.shapeColor = "maroon";

var papelao9 = createSprite(350,270, 100, 10); 
papelao9.shapeColor = "maroon";

var papelao10 = createSprite(180,310, 10, 90); 
papelao10.shapeColor = "maroon";

var papelao11 = createSprite(40,80, 10, 50); 
papelao11.shapeColor = "maroon";

var papelao12 = createSprite(250,200, 100, 10); 
papelao12.shapeColor = "maroon";

var papelao13 = createSprite(320,120, 240, 10); 
papelao13.shapeColor = "maroon";

var papelao14 = createSprite(230,160, 10, 90); 
papelao14.shapeColor = "maroon";

var papelao15 = createSprite(225,310, 10, 90); 
papelao15.shapeColor = "maroon";

var papelao16 = createSprite(150,40, 90, 10); 
papelao16.shapeColor = "maroon";

var papelao17 = createSprite(169,70, 10, 60); 
papelao17.shapeColor = "maroon";

var papelao18 = createSprite(370,70, 90, 10); 
papelao18.shapeColor = "maroon";

var papelao19 = createSprite(270,30, 10, 90); 
papelao19.shapeColor = "maroon";


function draw(){
background("black");

if (gameState == "serve")
{
  textSize(20);
  textAlign(LEFT, TOP);
  textFont("arial");
  fill("yellow");
  stroke("red");
  strokeWeight(5);
  text("aperte espaço para iniciar", 10, 0, 400, 400);
  
  if (keyDown("space"))
  {
     laser2.velocityY = -5;
     guarda1.velocityY = 5;
     guarda2.velocityX = -5;
     gameState = "play";
  }
  
}

if (gameState == "play")
{
   playerMoviment ();
  
   if (player.isTouching(diamante) || player.isTouching(laser1) || player.isTouching(laser2) || player.isTouching(guarda1))
   {
     gameState = "end";
   }
    
}

if (gameState == "end")
{
   laser2.velocityY = 0;
   guarda1.velocityY = 0;
   guarda2.velocityX = 0;
   textSize(20);
   textAlign(CENTER, CENTER);
   textFont("arial");
   fill("yellow");
   stroke("red");
   strokeWeight(5);
   text("fim de jogo!",190,220);
 
}

if (player.isTouching(diamante))
{
  diamante.remove(player);
}

if (player.isTouching(botao))
{
  botao.shapeColor = "orange";
  playSound("assets/category_bell/vibrant_game_bell_ding.mp3", false);
  laser1.remove(player);
  
}
  
  //player.x = 20;
  //player.y = 380;

function playerMoviment ()
{

if (keyDown("up"))
{ player.y = player.y -3;}

if (keyDown("down"))
{ player.y = player.y +3;}

if (keyDown("right"))
{ player.x = player.x +3;}

if (keyDown("left"))
{ player.x = player.x -3;}

}

createEdgeSprites();

laser2.bounceOff(papelao12);
laser2.bounceOff(papelao6);

player.collide(edges);

player.bounce(papelao1);
player.bounce(papelao2);
player.bounce(papelao3);
player.bounce(papelao4);
player.bounce(papelao5);
player.bounce(papelao6);
player.bounce(papelao7);
player.bounce(papelao8);
player.bounce(papelao9);
player.bounce(papelao10);
player.bounce(papelao11);
player.bounce(papelao12);
player.bounce(papelao13);
player.bounce(papelao14);
player.bounce(papelao15);
player.bounce(papelao16);
player.bounce(papelao17);
player.bounce(papelao18);
player.bounce(papelao19);

guarda1.bounceOff(papelao1);
guarda1.bounceOff(papelao5);

guarda2.bounceOff(papelao3);
guarda2.bounceOff(rightEdge);

drawSprites();

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
